# Simple Launcher (MVP)

Launcher Android ringan: Kotlin + XML Views + ViewBinding + MVVM + Hilt + Room + DataStore.
Min SDK 26 (Android 8.0), Target SDK 34.

## Cara membuka & build
1. Ekstrak zip ini, buka folder `SimpleLauncher` di **Android Studio** (Open an existing project).
2. Tunggu Gradle sync selesai (Android Studio otomatis mengunduh Gradle 8.7 sesuai `gradle-wrapper.properties`).
3. Ganti ikon placeholder: klik kanan `res` → New → Image Asset → pilih "Launcher Icons (Adaptive and Legacy)", supaya `ic_launcher_foreground.xml` diganti aset asli.
4. Jalankan di emulator/device Android 8.0+ (Run ▶).

## Cara menjadikan default launcher
1. Install & jalankan aplikasi minimal sekali.
2. Tekan tombol Home di device/emulator → sistem menampilkan dialog pemilihan launcher → pilih **Simple Launcher** → **Always** (Selalu).
3. Kalau dialog tidak muncul (karena sudah pernah pilih launcher lain), buka **Settings → Apps → Default apps → Home app** (nama menu bisa beda tiap vendor) lalu pilih Simple Launcher secara manual.

## Struktur project
```
app/src/main/java/com/simplelauncher/app/
├── SimpleLauncherApp.kt        # @HiltAndroidApp
├── MainActivity.kt             # Host tunggal, swap Fragment
├── data/
│   ├── model/AppInfo.kt        # Model runtime (dari PackageManager)
│   ├── local/
│   │   ├── entity/             # FavoriteAppEntity, HiddenAppEntity (Room)
│   │   ├── dao/                # FavoriteAppDao, HiddenAppDao
│   │   └── AppDatabase.kt
│   ├── datastore/SettingsDataStore.kt   # tema & jumlah kolom grid
│   └── repository/AppRepository.kt      # single source of truth
├── di/DatabaseModule.kt        # Hilt module untuk Room
└── ui/
    ├── home/                   # HomeFragment + HomeViewModel + FavoritesAdapter
    └── drawer/                 # AppDrawerFragment + AppDrawerViewModel + AppDrawerAdapter
```

## Fitur yang sudah jalan di MVP ini
- Home screen: jam, tanggal, search bar (tap → buka drawer), grid favorit, dock.
- App drawer: semua aplikasi terpasang, urut alfabet, search realtime.
- Long-press ikon → menu: Info Aplikasi, Tambah/Hapus Favorit, Pin ke Dock, Sembunyikan.
- Data favorit & hidden apps persist lewat Room; survive restart.
- Set sebagai default launcher via intent-filter HOME + DEFAULT.

## Catatan penting (izin, kebijakan, limitasi)

**QUERY_ALL_PACKAGES**
- Sejak Android 11 (API 30), akses ke daftar package lain dibatasi (Package Visibility).
  Karena targetSdk aplikasi ini 34, tanpa izin ini `queryIntentActivities` bisa jadi tidak
  melihat semua aplikasi di device Android 11+.
- Google Play **mengizinkan** `QUERY_ALL_PACKAGES` untuk aplikasi yang fungsi utamanya adalah
  launcher/home-screen replacement — tapi ini dinilai lewat *Play Console Declaration Form*
  saat submit, bukan otomatis. Jika ditolak reviewer, alternatifnya adalah mengandalkan penuh
  elemen `<queries>` (intent MAIN/LAUNCHER) di manifest, yang untuk kasus launcher biasanya
  sudah cukup — jadi kalau launcher ini bertujuan dipublikasikan ke Play Store, pertimbangkan
  untuk mengandalkan `<queries>` saja dan uji apakah semua app tetap terlihat di Android 11+
  sebelum menambahkan `QUERY_ALL_PACKAGES`.

**Wallpaper & status bar**
- `SET_WALLPAPER` dan `EXPAND_STATUS_BAR` sudah dideklarasikan tapi belum dipakai di kode MVP
  (wallpaper live di belakang home screen belum diimplementasikan — lihat roadmap).

**Kompatibilitas Android 8.0**
- `AdaptiveIconDrawable` (API 26) sudah dipakai lewat `mipmap-anydpi-v26/ic_launcher.xml`; di
  device < API 26 sistem otomatis fallback (tidak ada mipmap non-v26 di project ini, jadi
  sebaiknya tetap tambahkan PNG legacy lewat Image Asset Studio bila ingin support < API 26 —
  meski minSdk project ini sudah 26 sehingga secara teknis tidak wajib).
- Tidak ada pemanggilan API di atas level 26 yang butuh `Build.VERSION.SDK_INT` check di MVP ini,
  karena semua API yang dipakai (Room, DataStore, ViewBinding, RecyclerView, Fragment) sudah
  didukung AndroidX secara backward-compatible ke API 26.

**Background execution**
- Launcher berjalan sebagai Activity foreground saja di MVP ini (tidak ada Service), jadi tidak
  terdampak background execution limits Android 8+.

**Icon placeholder**
- `ic_launcher_foreground.xml` di project ini hanya vector placeholder (kotak-kotak putih).
  Ganti lewat Image Asset Studio sebelum rilis.

## Belum lanjut ke roadmap
Sesuai arahan, MVP dihentikan di sini dulu. Fitur lanjutan (widget/AppWidgetHost, gesture
swipe, backup/restore preferensi, icon pack, folder di home screen) belum diimplementasikan —
tanyakan kapan mau lanjut ke salah satunya dan saya akan bangun di atas struktur yang sama.
