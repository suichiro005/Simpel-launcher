# Aturan default cukup untuk MVP ini karena isMinifyEnabled = false.
# Tambahkan aturan keep di sini saat mengaktifkan R8/minify untuk build release.
