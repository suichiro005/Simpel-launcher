package com.simplelauncher.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.simplelauncher.app.databinding.ActivityMainBinding
import com.simplelauncher.app.ui.home.HomeFragment
import dagger.hilt.android.AndroidEntryPoint

/**
 * Satu-satunya Activity di launcher ini. Semua layar (home, app drawer)
 * adalah Fragment yang ditukar di dalam fragmentContainer, supaya launcher
 * tetap ringan dan proses tidak sering direstart oleh sistem.
 */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, HomeFragment())
                .commit()
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Layar Home tidak boleh "keluar" saat back ditekan.
        // Hanya proses back stack jika sedang ada fragment lain (mis. App Drawer) di atasnya.
        if (supportFragmentManager.backStackEntryCount > 0) {
            super.onBackPressed()
        }
    }
}
