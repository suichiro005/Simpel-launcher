package com.simplelauncher.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.simplelauncher.app.data.local.dao.FavoriteAppDao
import com.simplelauncher.app.data.local.dao.HiddenAppDao
import com.simplelauncher.app.data.local.entity.FavoriteAppEntity
import com.simplelauncher.app.data.local.entity.HiddenAppEntity

@Database(
    entities = [FavoriteAppEntity::class, HiddenAppEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteAppDao(): FavoriteAppDao
    abstract fun hiddenAppDao(): HiddenAppDao
}
