package com.simplelauncher.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Menyimpan aplikasi yang di-pin sebagai favorit.
 * [isDocked] membedakan apakah item ini muncul di grid utama home screen
 * atau di baris Dock (bawah layar).
 */
@Entity(tableName = "favorite_apps")
data class FavoriteAppEntity(
    @PrimaryKey val packageName: String,
    val activityName: String,
    val isDocked: Boolean = false,
    val sortOrder: Int = 0
)
