package com.simplelauncher.app.data.model

import android.graphics.drawable.Drawable

/**
 * Representasi runtime satu aplikasi terpasang.
 * Bukan Room entity -- data icon/label diambil langsung dari PackageManager,
 * sedangkan status favorit/hidden datang dari Room (join di Repository/ViewModel).
 */
data class AppInfo(
    val packageName: String,
    val activityName: String,
    val label: String,
    val icon: Drawable,
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false
)
