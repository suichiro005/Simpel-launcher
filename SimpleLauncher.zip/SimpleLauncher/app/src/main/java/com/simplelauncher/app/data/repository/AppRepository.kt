package com.simplelauncher.app.data.repository

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import com.simplelauncher.app.data.local.dao.FavoriteAppDao
import com.simplelauncher.app.data.local.dao.HiddenAppDao
import com.simplelauncher.app.data.local.entity.FavoriteAppEntity
import com.simplelauncher.app.data.local.entity.HiddenAppEntity
import com.simplelauncher.app.data.model.AppInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val favoriteAppDao: FavoriteAppDao,
    private val hiddenAppDao: HiddenAppDao
) {
    private val packageManager: PackageManager = context.packageManager

    /**
     * Mengambil semua aplikasi yang punya launcher icon (activity ACTION_MAIN + CATEGORY_LAUNCHER).
     * Berjalan di IO dispatcher karena query PackageManager cukup berat.
     */
    suspend fun getAllInstalledApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)

        resolveInfos.map { resolveInfo ->
            AppInfo(
                packageName = resolveInfo.activityInfo.packageName,
                activityName = resolveInfo.activityInfo.name,
                label = resolveInfo.loadLabel(packageManager).toString(),
                icon = resolveInfo.loadIcon(packageManager)
            )
        }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun getFavorites(): Flow<List<FavoriteAppEntity>> = favoriteAppDao.getAllFavorites()

    fun getHiddenApps(): Flow<List<HiddenAppEntity>> = hiddenAppDao.getAllHidden()

    suspend fun addFavorite(packageName: String, activityName: String, docked: Boolean = false) {
        favoriteAppDao.insert(FavoriteAppEntity(packageName, activityName, docked))
    }

    suspend fun pinToDock(packageName: String, activityName: String) {
        favoriteAppDao.insert(FavoriteAppEntity(packageName, activityName, isDocked = true))
    }

    suspend fun removeFavorite(packageName: String) {
        favoriteAppDao.deleteByPackageName(packageName)
    }

    suspend fun hideApp(packageName: String) {
        hiddenAppDao.insert(HiddenAppEntity(packageName))
    }

    suspend fun unhideApp(packageName: String) {
        hiddenAppDao.deleteByPackageName(packageName)
    }

    fun launchApp(packageName: String, activityName: String) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName(packageName, activityName)
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Aplikasi mungkin baru saja di-uninstall; abaikan dengan aman agar launcher tidak crash.
        }
    }

    fun openAppInfo(packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
