package com.simplelauncher.app.di

import android.content.Context
import androidx.room.Room
import com.simplelauncher.app.data.local.AppDatabase
import com.simplelauncher.app.data.local.dao.FavoriteAppDao
import com.simplelauncher.app.data.local.dao.HiddenAppDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(context, AppDatabase::class.java, "launcher_db")
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideFavoriteAppDao(database: AppDatabase): FavoriteAppDao = database.favoriteAppDao()

    @Provides
    fun provideHiddenAppDao(database: AppDatabase): HiddenAppDao = database.hiddenAppDao()
}
