package com.simplelauncher.app.ui.drawer

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import com.simplelauncher.app.R
import com.simplelauncher.app.data.model.AppInfo
import com.simplelauncher.app.databinding.FragmentAppDrawerBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class AppDrawerFragment : Fragment() {

    private var _binding: FragmentAppDrawerBinding? = null
    private val binding get() = _binding!!

    private val viewModel: AppDrawerViewModel by viewModels()
    private lateinit var adapter: AppDrawerAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAppDrawerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupSearch()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = AppDrawerAdapter(
            onClick = { viewModel.launchApp(it) },
            onLongClick = { app, anchor -> showAppMenu(app, anchor) }
        )
        binding.rvAppDrawer.apply {
            layoutManager = GridLayoutManager(requireContext(), GRID_SPAN_COUNT)
            adapter = this@AppDrawerFragment.adapter
        }
    }

    private fun setupSearch() {
        binding.etSearch.requestFocus()
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.setSearchQuery(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.visibleApps.collect { apps ->
                    adapter.submitList(apps)
                    binding.tvEmptyState.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    private fun showAppMenu(app: AppInfo, anchor: View) {
        PopupMenu(requireContext(), anchor).apply {
            menuInflater.inflate(R.menu.menu_app_long_press, menu)
            menu.findItem(R.id.action_favorite)?.title = if (app.isFavorite) {
                getString(R.string.remove_from_favorites)
            } else {
                getString(R.string.add_to_favorites)
            }
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.action_app_info -> { viewModel.openAppInfo(app); true }
                    R.id.action_favorite -> { viewModel.toggleFavorite(app); true }
                    R.id.action_pin_dock -> { viewModel.pinToDock(app); true }
                    R.id.action_hide -> { viewModel.hideApp(app); true }
                    else -> false
                }
            }
            show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val GRID_SPAN_COUNT = 4
    }
}
