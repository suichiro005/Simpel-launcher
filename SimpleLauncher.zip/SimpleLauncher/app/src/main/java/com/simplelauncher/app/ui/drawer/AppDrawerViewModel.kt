package com.simplelauncher.app.ui.drawer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.simplelauncher.app.data.model.AppInfo
import com.simplelauncher.app.data.repository.AppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AppDrawerViewModel @Inject constructor(
    private val repository: AppRepository
) : ViewModel() {

    private var allApps: List<AppInfo> = emptyList()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _visibleApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val visibleApps: StateFlow<List<AppInfo>> = _visibleApps.asStateFlow()

    init {
        viewModelScope.launch {
            allApps = repository.getAllInstalledApps()

            combine(
                repository.getFavorites(),
                repository.getHiddenApps(),
                _searchQuery
            ) { favorites, hidden, query ->
                val favoritePackages = favorites.map { it.packageName }.toSet()
                val hiddenPackages = hidden.map { it.packageName }.toSet()

                allApps
                    .asSequence()
                    .filter { it.packageName !in hiddenPackages }
                    .filter { query.isBlank() || it.label.contains(query, ignoreCase = true) }
                    .map { it.copy(isFavorite = it.packageName in favoritePackages) }
                    .toList()
            }.collect { filtered -> _visibleApps.value = filtered }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun launchApp(app: AppInfo) = repository.launchApp(app.packageName, app.activityName)

    fun openAppInfo(app: AppInfo) = repository.openAppInfo(app.packageName)

    fun toggleFavorite(app: AppInfo) {
        viewModelScope.launch {
            if (app.isFavorite) {
                repository.removeFavorite(app.packageName)
            } else {
                repository.addFavorite(app.packageName, app.activityName)
            }
        }
    }

    fun pinToDock(app: AppInfo) {
        viewModelScope.launch { repository.pinToDock(app.packageName, app.activityName) }
    }

    fun hideApp(app: AppInfo) {
        viewModelScope.launch { repository.hideApp(app.packageName) }
    }
}
