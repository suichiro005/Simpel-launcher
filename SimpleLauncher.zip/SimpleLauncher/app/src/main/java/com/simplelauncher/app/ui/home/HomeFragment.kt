package com.simplelauncher.app.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.simplelauncher.app.R
import com.simplelauncher.app.data.model.AppInfo
import com.simplelauncher.app.databinding.FragmentHomeBinding
import com.simplelauncher.app.ui.drawer.AppDrawerFragment
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels()

    private lateinit var gridAdapter: FavoritesAdapter
    private lateinit var dockAdapter: FavoritesAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClock()
        setupSearchBar()
        setupGrid()
        setupDock()
        observeViewModel()
    }

    private fun setupClock() {
        val now = Date()
        binding.tvClock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        binding.tvDate.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID")).format(now)
    }

    private fun setupSearchBar() {
        // Tap search bar langsung membuka App Drawer dengan fokus pencarian.
        binding.searchBar.setOnClickListener { openAppDrawer() }
    }

    private fun openAppDrawer() {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, AppDrawerFragment())
            .addToBackStack(null)
            .commit()
    }

    private fun setupGrid() {
        gridAdapter = FavoritesAdapter(
            onClick = { viewModel.launchApp(it) },
            onLongClick = { app, anchor -> showAppMenu(app, anchor) }
        )
        binding.rvFavoritesGrid.apply {
            layoutManager = GridLayoutManager(requireContext(), GRID_SPAN_COUNT)
            adapter = gridAdapter
            setHasFixedSize(true)
        }
    }

    private fun setupDock() {
        dockAdapter = FavoritesAdapter(
            onClick = { viewModel.launchApp(it) },
            onLongClick = { app, anchor -> showAppMenu(app, anchor) }
        )
        binding.rvDock.apply {
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            adapter = dockAdapter
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { viewModel.gridApps.collect { gridAdapter.submitList(it) } }
                launch { viewModel.dockApps.collect { dockAdapter.submitList(it) } }
            }
        }
    }

    private fun showAppMenu(app: AppInfo, anchor: View) {
        PopupMenu(requireContext(), anchor).apply {
            menuInflater.inflate(R.menu.menu_app_long_press, menu)
            // Dari home screen, item ini SUDAH favorit -> sembunyikan opsi "Pin ke Dock"
            // dan ubah label toggle favorit menjadi "Hapus dari Favorit".
            menu.findItem(R.id.action_pin_dock)?.isVisible = false
            menu.findItem(R.id.action_favorite)?.title = getString(R.string.remove_from_favorites)
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.action_app_info -> { viewModel.openAppInfo(app); true }
                    R.id.action_favorite -> { viewModel.removeFavorite(app); true }
                    R.id.action_hide -> { viewModel.hideApp(app); true }
                    else -> false
                }
            }
            show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val GRID_SPAN_COUNT = 4
    }
}
