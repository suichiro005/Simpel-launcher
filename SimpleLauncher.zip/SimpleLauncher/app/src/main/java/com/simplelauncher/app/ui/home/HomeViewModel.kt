package com.simplelauncher.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.simplelauncher.app.data.model.AppInfo
import com.simplelauncher.app.data.repository.AppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: AppRepository
) : ViewModel() {

    /** Aplikasi favorit yang tampil di grid utama home screen (tidak di-dock). */
    private val _gridApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val gridApps: StateFlow<List<AppInfo>> = _gridApps.asStateFlow()

    /** Aplikasi favorit yang di-pin ke Dock (baris bawah). */
    private val _dockApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val dockApps: StateFlow<List<AppInfo>> = _dockApps.asStateFlow()

    init {
        observeFavorites()
    }

    private fun observeFavorites() {
        viewModelScope.launch {
            // Daftar semua app di-cache sekali; cukup untuk MVP karena launcher
            // dihidupkan ulang tiap kali app diinstall/dihapus (lihat catatan roadmap).
            val allAppsByPackage = repository.getAllInstalledApps().associateBy { it.packageName }

            repository.getFavorites().collect { favorites ->
                _dockApps.value = favorites
                    .filter { it.isDocked }
                    .mapNotNull { allAppsByPackage[it.packageName] }

                _gridApps.value = favorites
                    .filter { !it.isDocked }
                    .mapNotNull { allAppsByPackage[it.packageName] }
            }
        }
    }

    fun launchApp(app: AppInfo) = repository.launchApp(app.packageName, app.activityName)

    fun openAppInfo(app: AppInfo) = repository.openAppInfo(app.packageName)

    fun removeFavorite(app: AppInfo) {
        viewModelScope.launch { repository.removeFavorite(app.packageName) }
    }

    fun hideApp(app: AppInfo) {
        viewModelScope.launch {
            repository.hideApp(app.packageName)
            repository.removeFavorite(app.packageName)
        }
    }
}
